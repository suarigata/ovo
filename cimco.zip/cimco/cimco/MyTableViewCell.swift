//
//  MyTableViewCell.swift
//  cimco
//
//  Created by iOS on 7/20/15.
//  Copyright (c) 2015 iOS. All rights reserved.
//

import UIKit

class MyTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titulo: UILabel!
    @IBOutlet weak var contentSnippet: UILabel!
    
    func load(entry : Entry){
        self.titulo.text=entry.title
        self.contentSnippet.text=entry.contentSnippet!.componentsSeparatedByString("\n")[0]
        if let data = entry.publishedDate{
            if NSCalendar.currentCalendar().isDateInToday(data){
                self.titulo.font = UIFont.boldSystemFontOfSize(17)
                self.contentSnippet.font = UIFont.boldSystemFontOfSize(14)
            }
            else{
                self.titulo.font = UIFont.systemFontOfSize(17)
                self.contentSnippet.font = UIFont.systemFontOfSize(14)
            }
        }
    }
}