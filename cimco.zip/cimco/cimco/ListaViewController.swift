//
//  ListaViewController.swift
//  cimco
//
//  Created by iOS on 7/20/15.
//  Copyright (c) 2015 iOS. All rights reserved.
//

import UIKit

class ListaViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    var entries : Entries!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        entries = Entries(nome: "new-pods", ext: "json")
        
        tableView.estimatedRowHeight = 88
        tableView.rowHeight = UITableViewAutomaticDimension
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
//        tableView.reloadData()
        tableView.reloadSections(NSIndexSet(index: 0), withRowAnimation: .Automatic)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.entries.lista.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("Cells", forIndexPath: indexPath) as! MyTableViewCell
        
        cell.load(self.entries.lista[indexPath.row])
        
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        UIApplication.sharedApplication().openURL(self.entries.lista[indexPath.row].link!)
        
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }
}