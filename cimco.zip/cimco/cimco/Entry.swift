//
//  Entry.swift
//  cimco
//
//  Created by iOS on 7/20/15.
//  Copyright (c) 2015 iOS. All rights reserved.
//

import Foundation

struct Entry{
    var title : String?
    var link : NSURL?
    var publishedDate : NSDate?
    var contentSnippet : String?
    var content : String?
}

class Entries{
    var dicionario : NSDictionary
    var lista : [Entry]
    
    init(nome : String,ext : String){
        var error: NSError?
        let filePath = NSBundle.mainBundle().pathForResource(nome, ofType: ext)
        let jsonData = NSData(contentsOfFile: filePath!)
        self.dicionario = NSJSONSerialization.JSONObjectWithData(jsonData!, options: nil, error: &error) as! NSDictionary
        
        let a=(self.dicionario["responseData"]) as! NSDictionary
        let b=a["feed"] as! NSDictionary
        let vetor=b["entries"] as! [NSDictionary]
        
        self.lista = []
        for item in vetor{
            let link = NSURL(string: item["link"] as! String)
            
            let formatter = NSDateFormatter()
            formatter.locale = NSLocale(localeIdentifier: "US_en")
            formatter.dateFormat = "EEE, d MMM yyyy HH:mm:ss Z"
            let date = formatter.dateFromString(item["publishedDate"] as! String)
            
            let entrada = Entry(title: item["title"] as? String, link: link, publishedDate: date, contentSnippet: item["contentSnippet"] as? String, content: item["content"] as? String)
            
            self.lista.append(entrada)
        }
    }
}